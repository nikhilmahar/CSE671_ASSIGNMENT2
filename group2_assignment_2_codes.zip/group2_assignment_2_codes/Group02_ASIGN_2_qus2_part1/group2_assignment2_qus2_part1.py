
import numpy as np
from numpy import random
import matplotlib.pyplot as plt
from sklearn.utils import shuffle

record=np.loadtxt("2.csv", delimiter=',')
input1 =record[:,0].reshape((len(record),1))
target=record[:,1].reshape((len(record),1))
plt.scatter(input1, target)
#training data
train_number=int(len(input1)*60/100)
X_train=input1[0:train_number,:]
X_train=X_train.reshape((len(X_train),1))
m,n=X_train.shape  #n= no. of input neurons # m=no. of train samples

# input_train=np.concatenate((np.ones((len(input_train),1)),input_train),1)

#training labels
Y_train=target[0:train_number,:]
Y_train=Y_train.reshape((len(Y_train),1))




N= 3 #NO. of neurons

M=1   #total number of output neurons
#training data
# train_number=int(len(class1_input)*60/100)
validation_number=int(len(input1)*20/100)
test_number=int(len(input1)*20/100)
# validation data
X_valid=input1[train_number:train_number+validation_number,:]
X_valid=X_valid.reshape((len(X_valid),1))

# input_train=np.concatenate((np.ones((len(input_train),1)),input_train),1)

#validation labels
Y_valid=target[train_number:train_number+validation_number,:]
Y_valid=Y_valid.reshape((len(Y_valid),1))


#validation data for network
# X_valid=np.concatenate((class1_valid,class2_valid,class3_valid),0)


# class12_train=np.concatenate((np.ones((len(class12_train),1)),class12_train),1)     #to include bias term
X_train,Y_train=shuffle(X_train,Y_train)
X_valid,Y_valid=shuffle(X_valid,Y_valid)
# X_train=X_train.T
# Y_train=Y_train.T
X_valid=X_valid.T
Y_valid=Y_valid.T


def init_params():
    
    W1 = np.random.rand(N, n) 
    b1 = np.random.rand(N, 1)
    W2 = np.random.rand(M, N) 
    b2 = np.random.rand(M, 1) 
    return W1, b1, W2, b2


def sigmoid(Z):
    f=1/(1+np.exp(-1*Z))
    return f

def softmax(Z):
    A = np.exp(Z) / sum(np.exp(Z))
    return A

def forward_prop(W1, b1, W2, b2, X):
    
    Z1 = W1.dot(X) + b1
    A1 = sigmoid(Z1)
    Z2 = W2.dot(A1) + b2
    A2 = Z2
    # print("x",X.shape,A1.shape,A2.shape)
    return Z1, A1, Z2, A2

def sigmoid_derivative(Z):
    dfda=Z*(1-Z)
    return dfda


def backward_prop(Z1, A1, Z2, A2, W1, W2, X, Y,index):
    dZ2 = Y[index,:]-A2
    # print(Y[index,:],A2,index)
    # loss=np.mean(dZ2**2)
    xx=(Y[index,:]-A2)**2
    loss=xx.reshape(1,1)
    dW2 = dZ2.dot(A1.T)
    db2 = dZ2
    dZ1 = W2.T.dot(dZ2) * sigmoid_derivative(A1)
    dW1 = dZ1.dot(X.T)
    db1 = dZ1
    
    # print("dz1",dZ1.shape,dW1.shape,db1.shape)
    return dW1, db1, dW2, db2, loss

def update_params(W1, b1, W2, b2, dW1, db1, dW2, db2, alpha):
    W1 = W1 + alpha * dW1
    b1 = b1 + alpha * db1    
    W2 = W2 + alpha * dW2  
    b2 = b2 + alpha * db2    
    return W1, b1, W2, b2

def gradient_descent(X, Y, alpha, epochs):
    iterations,_=X.shape
    avg_train_loss=[]
    avg_vald_loss=[]
    W1, b1, W2, b2 = init_params()
    for i in range(epochs):
        l=[];
        Y_train_pred=[]
        for j in range(iterations):
            # print("j",j)
            Z1, A1, Z2, A2 = forward_prop(W1, b1, W2, b2, X[j,:].reshape(1,1))
            Y_train_pred.append(A2)
            dW1, db1, dW2, db2, loss = backward_prop(Z1, A1, Z2, A2, W1, W2, X[j,:].reshape(1,1), Y,j)
            l.append(loss)
            W1, b1, W2, b2 = update_params(W1, b1, W2, b2, dW1, db1, dW2, db2, alpha)
        if i % 1 == 0:
            avg_train_loss.append(np.mean(l))
            def make_predictions(X_val, W1, b1, W2, b2):
                _, _, _, A2 = forward_prop(W1, b1, W2, b2, X_val)
                val_pred=A2
                return val_pred
             
            def val_prediction(X_val,Y_val, W1, b1, W2, b2):
                val_pred = make_predictions(X_val, W1, b1, W2, b2)
                xx=(Y_val-val_pred)**2
                val_loss=np.mean(xx)
                return val_pred,val_loss
                

            val_pred,val_loss=val_prediction(X_valid,Y_valid, W1, b1, W2, b2) 
            avg_vald_loss.append(val_loss)
            print("epoch: ", i,"training loss",np.mean(l),"validation loss", val_loss)
            if (np.mean(l)<4e-3):
                plt.figure()
                plt.plot(avg_train_loss)  
                plt.xlabel("Epochs")
                plt.ylabel("loss")
                plt.legend(["training loss"])
                plt.show    
                plt.figure()
                plt.plot(avg_vald_loss,color="orange") 
                plt.xlabel("Epochs")
                plt.ylabel("loss")
                plt.legend(["validation loss"])
                plt.show()  
                return W1, b1, W2, b2, val_pred, Y_train_pred
            
                
    # =============================================================================
    # plot average error
    # =============================================================================
    # plt.figure()
    # plt.plot(avg_train_loss)  
    # plt.plot(avg_vald_loss) 
    # plt.xlabel("Epochs")
    # plt.ylabel("loss")
    # plt.legend(["training loss", "validation loss"])
    # plt.show    
    # return W1, b1, W2, b2, val_pred,Y_train_pred
    else:
        plt.figure()
        plt.plot(avg_train_loss)  
        plt.xlabel("Epochs")
        plt.ylabel("loss")
        plt.legend(["training loss"])
        plt.show    
        plt.figure()
        plt.plot(avg_vald_loss,color="orange") 
        plt.xlabel("Epochs")
        plt.ylabel("loss")
        plt.legend(["validation loss"])
        plt.show()  
        return W1, b1, W2, b2, val_pred, Y_train_pred
W1, b1, W2, b2, val_pred,Y_train_pred = gradient_descent(X_train, Y_train, 0.010, 10000)


# =============================================================================
# Testing 
# =============================================================================
    
#testing data
X_test=input1[train_number+validation_number:len(input1),:]
X_test=X_test.reshape((len(X_test),1))



#test labels
Y_test=target[train_number+validation_number:len(target),:]
Y_test=Y_test.reshape((len(Y_test),1))


#testing data

X_test=X_test.T
Y_test=Y_test.T
# class12_test=np.concatenate((np.ones((len(class12_test),1)),class12_test),1)     #to include bias term



def make_predictions(X_test, W1, b1, W2, b2):
    _, _, _, A2 = forward_prop(W1, b1, W2, b2, X_test)
    test_pred=A2
    return test_pred
 
def test_prediction(X_test,Y_test, W1, b1, W2, b2):
    test_pred = make_predictions(X_test, W1, b1, W2, b2)
    # one_hot_Y = one_hot(Y_test)
    # print(test_pred.shape,one_hot_Y.shape)
    # test_loss=np.mean(-np.log(test_pred))
    xx=(Y_test-test_pred)**2
    test_loss=np.mean(xx)
    # test_loss=np.mean((test_pred-one_hot_Y)**2)
    return test_pred,test_loss
    

test_pred,test_loss=test_prediction(X_test,Y_test, W1, b1, W2, b2) 
print("test loss",test_loss)



plt.scatter(input1, target)
plt.xlabel("input")
plt.ylabel("target")
# plt.legend(["Predited","True"])
# plt.title("model output vs test targets")
plt.show()

plt.scatter(X_test[:,:],np.array(test_pred))
plt.scatter(X_test, Y_test)
plt.legend(["Predited","True"])
plt.title("model output vs test targets")
plt.show()

plt.scatter(X_train[:,:],np.array(Y_train_pred))
plt.scatter(X_train, Y_train)
plt.legend(["Predited","True"])
plt.title("model output vs train targets")
plt.show()

plt.scatter(X_valid[:,:],np.array(val_pred))
plt.scatter(X_valid, Y_valid)
plt.legend(["Predited","True"])
plt.title("model output vs validation targets")
plt.show()


# plt.plot(np.array(train_lpe_avg).reshape(len(train_lpe_avg),1))
# # plt.legend("Training loss")
# plt.title("Average Error vs epochs")
# plt.xlabel("epochs")
# plt.ylabel("Training loss")
# plt.show()

# test_pred1=np.array(test_pred).reshape(X_test.shape)
plt.scatter(Y_test,test_pred)
plt.xlabel("Test target")
plt.ylabel("model output")
plt.title("Model output vs Test target")
plt.show()

# train_pred1=np.array(train_pred).reshape(target_train.shape)
plt.scatter(Y_train,Y_train_pred)
plt.xlabel("Training target")
plt.ylabel("model output")
plt.title("Model output vs Training target")
plt.show()

plt.scatter(Y_valid,val_pred)
plt.xlabel("Validation target")
plt.ylabel("model output")
plt.title("Model output vs Validation target")
plt.show()


# =============================================================================
# Output of hidden neurons 
# =============================================================================
_, A1_TRAIN, _, _ = forward_prop(W1, b1, W2, b2, X_train.T) 
_, A1_TEST, _, _ = forward_prop(W1, b1, W2, b2, X_test)   
_, A1_VALIDATION, _, _ = forward_prop(W1, b1, W2, b2, X_valid) 
for i in range(len(A1_TRAIN)):
    plt.figure(figsize=(8,4))
    ax = plt.axes() 
    ax.scatter(X_train[:,:],A1_TRAIN[i,:],color="brown")
    # plt.title(i+1)
    plt.xlabel("feature x")
    plt.ylabel("Neuron output")
    plt.title("Neuron %i"%(i+1))
    # plt.text(1.065,0.7,"Training step: %i"%(i+1),fontsize="xx-large",color="k")
    plt.axis("on")
    
    plt.figure(figsize=(8,4))
    ax = plt.axes() 
    ax.scatter(X_test[:,:],A1_TEST[i,:],color="red")
    # plt.title(i+1)
    plt.xlabel("feature x")
    plt.ylabel("Neuron output")
    plt.title("Neuron %i"%(i+1))
    # plt.text(1.065,0.7,"Training step: %i"%(i+1),fontsize="xx-large",color="k")
    plt.axis("on")
    
    plt.figure(figsize=(8,4))
    ax = plt.axes() 
    ax.scatter(X_valid[:,:],A1_VALIDATION[i,:],color="green")
    # plt.title(i+1)
    plt.xlabel("feature x")
    plt.ylabel("Neuron output")
    plt.title("Neuron %i"%(i+1))
    # plt.text(1.065,0.7,"Training step: %i"%(i+1),fontsize="xx-large",color="k")
    plt.axis("on")
    
    
# =============================================================================
# Output of output neurons 
# =============================================================================
_, _, _, A2_TRAIN = forward_prop(W1, b1, W2, b2, X_train.T) 
_, _, _, A2_TEST = forward_prop(W1, b1, W2, b2, X_test)   
_, _, _, A2_VALIDATION = forward_prop(W1, b1, W2, b2, X_valid) 
for i in range(len(A2_TRAIN)):
    plt.figure(figsize=(8,4))
    ax = plt.axes() 
    ax.scatter(X_train[:,:],A2_TRAIN[i,:],color="brown")
    # plt.title(i+1)
    plt.xlabel("feature x")
    plt.ylabel("Neuron output")
    plt.title("Neuron %i"%(i+1))
    # plt.text(1.065,0.7,"Training step: %i"%(i+1),fontsize="xx-large",color="k")
    plt.axis("on")
    
    plt.figure(figsize=(8,4))
    ax = plt.axes() 
    ax.scatter(X_test[0,:],A2_TEST[i,:],color="red")
    # plt.title(i+1)
    plt.xlabel("feature x")
    plt.ylabel("Neuron output")
    plt.title("Neuron %i"%(i+1))
    # plt.text(1.065,0.7,"Training step: %i"%(i+1),fontsize="xx-large",color="k")
    plt.axis("on")
    
    plt.figure(figsize=(8,4))
    ax = plt.axes() 
    ax.scatter(X_valid[:,:],A2_VALIDATION[i,:],color="green")
    # plt.title(i+1)
    plt.xlabel("feature x")
    plt.ylabel("Neuron output")
    plt.title("Neuron %i"%(i+1))
    # plt.text(1.065,0.7,"Training step: %i"%(i+1),fontsize="xx-large",color="k")
    plt.axis("on")