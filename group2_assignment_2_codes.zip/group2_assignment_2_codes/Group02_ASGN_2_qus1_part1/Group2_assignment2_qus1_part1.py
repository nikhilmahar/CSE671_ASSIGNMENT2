
import numpy as np
from numpy import random
import matplotlib.pyplot as plt
from sklearn.utils import shuffle


class1_input = np.loadtxt("Class1.txt")
class2_input = np.loadtxt("Class2.txt")
class3_input = np.loadtxt("Class3.txt")
plt.scatter(class1_input[:,0],class1_input[:,1])
plt.scatter(class2_input[:,0],class2_input[:,1])
plt.scatter(class3_input[:,0],class3_input[:,1])
plt.show()
N=3 #NO. of neurons
M=3   #total number of classes
#training data
train_number=int(len(class1_input)*60/100)
validation_number=int(len(class1_input)*20/100)
class1_train=class1_input[0:train_number,:]
class2_train=class2_input[0:train_number,:]
class3_train=class3_input[0:train_number,:]

# validation data
class1_valid=class1_input[train_number:train_number+validation_number,:]
class2_valid=class2_input[train_number:train_number+validation_number,:]
class3_valid=class3_input[train_number:train_number+validation_number,:]
#training labels
class1_label=np.ones((len(class1_train),1))
class2_label=2*np.ones((len(class2_train),1))
class3_label=3*np.ones((len(class3_train),1))

#validation labels
class1_valid_label=np.ones((len(class1_valid),1))
class2_valid_label=2*np.ones((len(class2_valid),1))
class3_valid_label=3*np.ones((len(class3_valid),1))
#training labels for N12
Y_train=np.concatenate((class1_label,class2_label,class3_label),0)
Y_train=Y_train.T.astype(int)

Y_valid=np.concatenate((class1_valid_label,class2_valid_label,class3_valid_label),0)
Y_valid=Y_valid.T.astype(int)

#training data for network
X_train=np.concatenate((class1_train,class2_train,class3_train),0)
X_train=X_train.T
n,m=X_train.shape  #n= no. of input neurons # m=no. of train samples

#validation data for network
X_valid=np.concatenate((class1_valid,class2_valid,class3_valid),0)
X_valid=X_valid.T
n_v,m_v=X_train.shape  #n= no. of input neurons # m=no. of validation samples
# class12_train=np.concatenate((np.ones((len(class12_train),1)),class12_train),1)     #to include bias term
X_train,Y_train=shuffle(X_train.T,Y_train.T)
X_valid,Y_valid=shuffle(X_valid.T,Y_valid.T)
X_train=X_train.T
Y_train=Y_train.T
X_valid=X_valid.T
Y_valid=Y_valid.T


def init_params():
    W1 = np.random.rand(N, n) 
    b1 = np.random.rand(N, 1)
    W2 = np.random.rand(M, N) 
    b2 = np.random.rand(M, 1) 
    return W1, b1, W2, b2


def sigmoid(Z):
    f=1/(1+np.exp(-1*Z))
    return f

def softmax(Z):
    A = np.exp(Z) / sum(np.exp(Z))
    return A

def forward_prop(W1, b1, W2, b2, X):
    
    Z1 = W1.dot(X) + b1
    A1 = sigmoid(Z1)
    Z2 = W2.dot(A1) + b2
    A2 = softmax(Z2)
    # print("x",X.shape,A1.shape,A2.shape)
    return Z1, A1, Z2, A2

def sigmoid_derivative(Z):
    dfda=Z*(1-Z)
    return dfda


def one_hot(Y):
    one_hot_Y = np.zeros((Y.size, Y.max()))
    one_hot_Y[np.arange(Y.size), Y-1] = 1
    one_hot_Y = one_hot_Y.T
    # print("onehot",one_hot_Y.shape)
    return one_hot_Y

def backward_prop(Z1, A1, Z2, A2, W1, W2, X, Y,index):
    one_hot_Y = one_hot(Y)
    # print("one hot",one_hot_Y[:,index].shape)
    dZ2 = one_hot_Y[:,index].reshape(len(one_hot_Y),1)-A2
    # loss=np.mean(dZ2**2)
    xx=-one_hot_Y[:,index].reshape(len(one_hot_Y),1)*np.log(A2)
    xx1=np.sum(xx,axis=0)
    loss=xx1.reshape(1,len(xx1))
    # print("xx",xx)
    # print(xx1)
    # loss=np.mean(xx1)
    dW2 = dZ2.dot(A1.T)
    db2 = dZ2
    dZ1 = W2.T.dot(dZ2) * sigmoid_derivative(A1)
    dW1 = dZ1.dot(X.T)
    db1 = dZ1
    # print("dz1",dZ1.shape,dW1.shape,db1.shape)
    return dW1, db1, dW2, db2, loss

def update_params(W1, b1, W2, b2, dW1, db1, dW2, db2, alpha):
    W1 = W1 + alpha * dW1
    b1 = b1 + alpha * db1    
    W2 = W2 + alpha * dW2  
    b2 = b2 + alpha * db2    
    return W1, b1, W2, b2

def gradient_descent(X, Y, alpha, epochs):
    _,iterations=X.shape
    avg_train_loss=[]
    avg_vald_loss=[]
    W1, b1, W2, b2 = init_params()
    for i in range(epochs):
        l=[];
        for j in range(iterations):
            Z1, A1, Z2, A2 = forward_prop(W1, b1, W2, b2, X[:,j].reshape(len(X_train),1))
            dW1, db1, dW2, db2, loss = backward_prop(Z1, A1, Z2, A2, W1, W2, X[:,j].reshape(len(X_train),1), Y,j)
            l.append(loss)
            W1, b1, W2, b2 = update_params(W1, b1, W2, b2, dW1, db1, dW2, db2, alpha)
        if i % 1 == 0:
            avg_train_loss.append(np.mean(l))
            def make_predictions(X_val, W1, b1, W2, b2):
                _, _, _, A2 = forward_prop(W1, b1, W2, b2, X_val)
                val_pred=A2
                return val_pred
            def val_prediction(X_val,Y_val, W1, b1, W2, b2):
                val_pred = make_predictions(X_val, W1, b1, W2, b2)
                one_hot_Y = one_hot(Y_val)
                # test_loss=np.mean(-np.log(test_pred))
                xx=-one_hot_Y*np.log(val_pred)
                xx1=np.sum(xx,axis=0)
                xx1=xx1.reshape(1,len(xx1))
                # print(xx.shape)
                # print(xx1.shape)
                val_loss=np.mean(xx1)
                # test_loss=np.mean((test_pred-one_hot_Y)**2)
                return val_pred,val_loss
                

            val_pred,val_loss=val_prediction(X_valid,Y_valid, W1, b1, W2, b2) 
            avg_vald_loss.append(val_loss)
            print("epoch: ", i,"training loss",np.mean(l),"validation loss", val_loss)
            if (np.mean(l)<1e-3):
                plt.figure()
                plt.plot(avg_train_loss)  
                plt.xlabel("Epochs")
                plt.ylabel("loss")
                plt.legend(["training loss"])
                plt.show    
                plt.figure()
                plt.plot(avg_vald_loss,color="orange") 
                plt.xlabel("Epochs")
                plt.ylabel("loss")
                plt.legend(["validation loss"])
                plt.show    
                return W1, b1, W2, b2, val_pred
                
                
                
    # # =============================================================================
    # # plot average error
    # # =============================================================================
    # plt.figure()
    # plt.plot(avg_train_loss)  
    # plt.plot(avg_vald_loss) 
    # plt.xlabel("Epochs")
    # plt.ylabel("loss")
    # plt.legend(["training loss", "validation loss"])
    # plt.show    
    # return W1, b1, W2, b2, val_pred

W1, b1, W2, b2, val_pred = gradient_descent(X_valid, Y_valid, 0.010, 10000)

# =============================================================================
# confusion matrix for validation data
# =============================================================================
def compute_confusion_matrix(true, pred):
  K = M # Number of classes 
  result = np.zeros((K, K))

  for i in range(len(true.T)):
      index=true.argmax(axis=0)
      result[int(true[:,i].argmax(axis=0))][int(pred[:,i].argmax(axis=0))] += 1

  return result

val_pred1=one_hot(Y_valid)*np.round(val_pred)    
confusion_matrix_valid=compute_confusion_matrix(one_hot(Y_valid), val_pred1)    


# =============================================================================
# Testing 
# =============================================================================
    
#testing data
# train_number=int(len(class1_input)*70/100)
class1_test=class1_input[train_number+validation_number:len(class1_input),:]
class2_test=class2_input[train_number+validation_number:len(class2_input),:]
class3_test=class3_input[train_number+validation_number:len(class3_input),:]
#test labels
class1_test_label=np.ones((len(class1_test),1))
class2_test_label=2*np.ones((len(class2_test),1))
class3_test_label=3*np.ones((len(class3_test),1))
#test labels for N12
Y_test=np.concatenate((class1_test_label,class2_test_label,class3_test_label),0)
Y_test=Y_test.T.astype(int)

#testing data for N12 Perceptron
X_test=np.concatenate((class1_test,class2_test,class3_test),0)
X_test=X_test.T.astype(int)
# class12_test=np.concatenate((np.ones((len(class12_test),1)),class12_test),1)     #to include bias term



def make_predictions(X_test, W1, b1, W2, b2):
    _, _, _, A2 = forward_prop(W1, b1, W2, b2, X_test)
    test_pred=A2
    return test_pred
 
def test_prediction(X_test,Y_test, W1, b1, W2, b2):
    test_pred = make_predictions(X_test, W1, b1, W2, b2)
    one_hot_Y = one_hot(Y_test)
    # print(test_pred.shape,one_hot_Y.shape)
    # test_loss=np.mean(-np.log(test_pred))
    xx=-one_hot_Y*np.log(test_pred)
    xx1=np.sum(xx,axis=0)
    xx1=xx1.reshape(1,len(xx1))
    # print(xx.shape)
    # print(xx1)
    test_loss=np.mean(xx1)
    # test_loss=np.mean((test_pred-one_hot_Y)**2)
    return test_pred,test_loss
    

test_pred,test_loss=test_prediction(X_test,Y_test, W1, b1, W2, b2) 
print("test loss",test_loss)

# =============================================================================
# confusion matrix for test data
# =============================================================================
test_pred1=one_hot(Y_test)*np.round(test_pred) 
confusion_matrix_test=compute_confusion_matrix(one_hot(Y_test), test_pred1) 


# =============================================================================
# plot decision boundary for 3 classes
# =============================================================================
        
x=np.linspace(-10, 20,300)
y=np.linspace(-30, 10,300)
X1,Y1=np.meshgrid(x, y)
X=X1.flatten()
X=X.reshape(len(X),1)
Y=Y1.flatten()
Y=Y.reshape(len(Y),1)
XY_TEST=np.concatenate((X,Y),1).T

def XY_test_prediction(X_test, W1, b1, W2, b2):
    test_pred = make_predictions(X_test, W1, b1, W2, b2)
    return test_pred
XY_test_pred=XY_test_prediction(XY_TEST, W1, b1, W2, b2) 
max_index=XY_test_pred.argmax(axis=0).reshape(X1.shape)


plt.figure()
plt.contourf(X1,Y1,max_index)
plt.scatter(class1_input[:,0],class1_input[:,1])
plt.scatter(class2_input[:,0],class2_input[:,1])
plt.scatter(class3_input[:,0],class3_input[:,1])
plt.show()

# =============================================================================
# Output of hidden neurons 
# =============================================================================
_, A1_TRAIN, _, _ = forward_prop(W1, b1, W2, b2, X_train) 
_, A1_TEST, _, _ = forward_prop(W1, b1, W2, b2, X_test)   
_, A1_VALIDATION, _, _ = forward_prop(W1, b1, W2, b2, X_valid) 
for i in range(len(A1_TRAIN)):
    plt.figure(figsize=(8,4))
    ax = plt.axes(projection ="3d") 
    ax.scatter3D(X_train[0,:],X_train[1,:],A1_TRAIN[i,:],color="brown")
    # plt.title(i+1)
    plt.xlabel("feature x")
    plt.ylabel("feature y")
    plt.title("Neuron %i"%(i+1))
    # plt.text(1.065,0.7,"Training step: %i"%(i+1),fontsize="xx-large",color="k")
    plt.axis("on")
    
    plt.figure(figsize=(8,4))
    ax = plt.axes(projection ="3d") 
    ax.scatter3D(X_test[0,:],X_test[1,:],A1_TEST[i,:],color="red")
    # plt.title(i+1)
    plt.xlabel("feature x")
    plt.ylabel("feature y")
    plt.title("Neuron %i"%(i+1))
    # plt.text(1.065,0.7,"Training step: %i"%(i+1),fontsize="xx-large",color="k")
    plt.axis("on")
    
    plt.figure(figsize=(8,4))
    ax = plt.axes(projection ="3d") 
    ax.scatter3D(X_valid[0,:],X_valid[1,:],A1_VALIDATION[i,:],color="green")
    # plt.title(i+1)
    plt.xlabel("feature x")
    plt.ylabel("feature y")
    plt.title("Neuron %i"%(i+1))
    # plt.text(1.065,0.7,"Training step: %i"%(i+1),fontsize="xx-large",color="k")
    plt.axis("on")
    
    
# =============================================================================
# Output of output neurons 
# =============================================================================
_, _, _, A2_TRAIN = forward_prop(W1, b1, W2, b2, X_train) 
_, _, _, A2_TEST = forward_prop(W1, b1, W2, b2, X_test)   
_, _, _, A2_VALIDATION = forward_prop(W1, b1, W2, b2, X_valid) 
for i in range(len(A2_TRAIN)):
    plt.figure(figsize=(8,4))
    ax = plt.axes(projection ="3d") 
    ax.scatter3D(X_train[0,:],X_train[1,:],A2_TRAIN[i,:],color="brown")
    # plt.title(i+1)
    plt.xlabel("feature x")
    plt.ylabel("feature y")
    plt.title("Neuron %i"%(i+1))
    # plt.text(1.065,0.7,"Training step: %i"%(i+1),fontsize="xx-large",color="k")
    plt.axis("on")
    
    plt.figure(figsize=(8,4))
    ax = plt.axes(projection ="3d") 
    ax.scatter3D(X_test[0,:],X_test[1,:],A2_TEST[i,:],color="red")
    # plt.title(i+1)
    plt.xlabel("feature x")
    plt.ylabel("feature y")
    plt.title("Neuron %i"%(i+1))
    # plt.text(1.065,0.7,"Training step: %i"%(i+1),fontsize="xx-large",color="k")
    plt.axis("on")
    
    plt.figure(figsize=(8,4))
    ax = plt.axes(projection ="3d") 
    ax.scatter3D(X_valid[0,:],X_valid[1,:],A2_VALIDATION[i,:],color="green")
    # plt.title(i+1)
    plt.xlabel("feature x")
    plt.ylabel("feature y")
    plt.title("Neuron %i"%(i+1))
    # plt.text(1.065,0.7,"Training step: %i"%(i+1),fontsize="xx-large",color="k")
    plt.axis("on")